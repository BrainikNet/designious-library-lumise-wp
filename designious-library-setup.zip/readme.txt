=== Designious Library Lumise Addon ===
Contributors: designious
Tags: design library,lumise,graphic design,ecommerce,store,sell,t-shirt design
Requires at least: 3.5.0
Tested up to: 5.6
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Designious Library Lumise Addon is a plugin that helps users install the latest addon for the Lumise Product Designer. The addon provides access to the Designious Library with more than 15.000 design assets that can be used to create print on demand products like t-shirts, mugs, posters and more. 

== Description ==

Designious Library Lumise Addon features:

» Install the latest Designious Library Lumise Addon
» Enter your license
» Start using the library


**Designious Library Lumise Addon** sign up for a free license here from https://designious.com/designious-library-lumise-add-on/, contact us for support at support@designious.com.




